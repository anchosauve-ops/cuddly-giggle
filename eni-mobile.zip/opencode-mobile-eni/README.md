# ENI Mobile

Personal Android client for OpenCode.

Built for **one operator**. Red-team oriented. Small font. Dark. Fast tool approvals. Local secrets only. No telemetry.

## What is better about this version

- **Dense small-font UI** (10–13 px) tuned for long sessions
- **Biometric lock** on every open
- **Hardened OpenCode client** that tries multiple common endpoint shapes so it works with more server builds
- **Big thumb-zone Approve / Deny** permission bar with haptics
- **Local notes** per session (findings stay on device)
- **Wipe local cache** — one tap, clears messages + notes from the phone
- Auto health + session refresh
- Low-glare dark theme, amber accent, almost zero chrome
- Connection profiles with passwords only in SecureStore

## Stack

- Expo SDK 52 + React Native + Expo Router
- Zustand
- Axios
- expo-secure-store / local-authentication / haptics

## Project layout

```
app/
  (tabs)/          Sessions · Terminal · Files · Settings
  session/[id]     Chat + tool approval + local notes
  connection/add   Add server profile
src/
  components/      Button, MessageBubble, PermissionBar, SessionItem
  lib/             sdk.ts (OpenCode client), secure.ts
  stores/          appStore
  theme/           colors + typography (small font locked)
  types/
```

## Run on your phone

```bash
cd opencode-mobile-eni
npm install
npx expo start
```

Scan with Expo Go, or:

```bash
npx expo run:android
```

## Typical flow

1. Run `opencode serve` (or your usual headless server) on the box that has the workspace
2. Expose it (Tailscale / Cloudflare Tunnel / reverse proxy / LAN)
3. In ENI Mobile → + Conn → paste URL + credentials
4. Sessions appear. Open one. Prompt. Approve tools with your thumb.
5. Drop local notes for findings. Wipe when done.

## Design rules

- Font size stays small
- One-handed primary actions
- No accounts, no cloud, no analytics
- Secrets never leave SecureStore
- Server is source of truth; phone is a control surface + local scratchpad

## Still coming

- True SSE streaming (currently poll + prompt)
- Real PTY terminal
- File tree + @-mention
- Voice loop
- Diff viewer with hunk actions

This is yours. No one else gets a copy.
